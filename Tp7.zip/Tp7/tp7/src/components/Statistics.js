import React from 'react';
import Personas from './Personas';
import './Statistics.css'; // Estilos específicos para Statistics

const Statistics = () => {
  const mayoresDe35 = Personas.filter(person => person.age > 35);
  const mayorEdad = Math.max(...Personas.map(person => person.age));
  const personasMayorEdad = Personas.filter(person => person.age === mayorEdad);
  const menorEdad = Math.min(...Personas.map(person => person.age));
  const personasMenorEdad = Personas.filter(person => person.age === menorEdad);

  return (
    <div className="container statistics-container">
      <h2>Estadísticas</h2>
      <p>Mayores de 35 años: {mayoresDe35.length}</p>
      <p>Persona(s) de mayor edad: {personasMayorEdad.map(person => person.name).join(', ')}</p>
      <p>Persona(s) de menor edad: {personasMenorEdad.map(person => person.name).join(', ')}</p>
    </div>
  );
};

export default Statistics;

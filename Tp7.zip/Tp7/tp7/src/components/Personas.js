const Personas = [
    {
      id: 1,
      name: 'Juan Pérez',
      age: 28,
      email: 'juanperez@gmail.com',
    },
    {
      id: 2,
      name: 'María González',
      age: 40,
      email: 'mariagonzalez@gmail.com',
    },
    {
      id: 3,
      name: 'Carlos Sánchez',
      age: 22,
      email: 'carlossanchez@gmail.com',
    },
    // Agrega más objetos de persona según sea necesario
  ];
  
  export default Personas;
  
import React from 'react';
import { useParams } from 'react-router-dom';
import Personas from './Personas';
import './Person.css'; // Estilos específicos para Person

const Person = () => {
  const { id } = useParams();
  const person = Personas.find(person => person.id === parseInt(id));

  if (!person) {
    return <div className="container person-container">Persona no encontrada.</div>;
  }

  return (
    <div className="container person-container">
      <h2>Información de {person.name}</h2>
      <p>Edad: {person.age}</p>
      <p>Email: {person.email}</p>
    </div>
  );
};

export default Person;
